
function TermsofService(){
    return(

        <h1>Terms of Service</h1>

    )

}
export default TermsofService;